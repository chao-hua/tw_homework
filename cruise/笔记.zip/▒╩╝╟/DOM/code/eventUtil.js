var eventUtil = {
    /*
     *添加bubble类型跨浏览器事件处理程序
     *
     *  element:绑定事件的DOM节点
     *  type:事件类型，不加on,e.g:click
     *  handler:处理函数
     */
    addHandler: function(element, type, handler) {
        //如果支持DOM2级事件处理程序
        if (element.addEventListener) {
            element.addEventListener(type, handler, false);
            //如果支持IE事件处理程序
        } else if (element.attachEvent) {
            element.attachEvent('on' + type, handler);
            //其他使用DOM0级事件处理程序
        } else {
            //js中：对象.属性 = 对象[属性]
            element['on' + type] = handler;
        }
    },

    /*
     *删除bubble类型跨浏览器事件处理程序
     *
     *  element:绑定事件的DOM节点
     *  type:事件类型，不加on,e.g:click
     *  handler:处理函数
     */
    removeHandler: function(element, type, handler) {
        //如果支持DOM2级事件处理程序
        if (element.removeEventListener) {
            element.removeEventListener(type, handler, false);
            //如果支持IE事件处理程序
        } else if (element.detachEvent) {
            element.detachEvent('on' + type, handler);
            //其他使用DOM0级事件处理程序
        } else {
            element['on' + type] = null;
        }
    },

    /*
     *获取跨浏览器event对象
     *
     *  e:event对象
     */
    getEvent: function(e) {
        return e || window.e;
    },

    /*
     *获取跨浏览器事件目标
     *
     *  e:event对象
     */
    getEventTarget: function(e) {
        return e.target || e.srcElement;
    },

    /*
     *跨浏览器阻止事件默认行为
     *
     *  e:event对象
     */
    preventDefault: function(e) {
        if (e.preventDefault) {
            e.preventDefault();
        } else {
            return false;
        }
    },

    /*
     *跨浏览器阻止事件传播
     *
     *  e:event对象
     */
    stopPropagation: function(e) {
        if (e.stopPropagation) {
            e.stopPropagation();
        } else {
            e.cancelBubble = true;
        }
    }
};
